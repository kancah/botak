from simpelalf import *

@bot.on(events.CallbackQuery(data=b'cuek-ssh'))
async def cuek_ssh(event):
	async def cuek_ssh_(event):
		cmd = 'botcekssh'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
**Shows Logged In Users SSH**
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await cuek_ssh_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'cuek-shadowsocks'))
async def cuek_shadowsocks(event):
	async def cuek_shadowsocks_(event):
		cmd = 'botcekss'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
**Shows Logged In Users Shadowsocks**
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await cuek_shadowsocks_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'cuek-trojan'))
async def cuek_trojan(event):
	async def cuek_trojan_(event):
		cmd = 'botcektr'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
**Shows Logged In Users Trojan**
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await cuek_trojan_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'cuek-vless'))
async def cuek_vless(event):
	async def cuek_vless_(event):
		cmd = 'botcekvl'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
**Shows Logged In Users Vless**
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await cuek_vless_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'cuek-vmess'))
async def cuek_vmess(event):
	async def cuek_vmess_(event):
		cmd = 'botcekvm'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""

{z}
**Shows Logged In Users Vmess**
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await cuek_vmess_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'ptg-serper'))
async def ptg_serper(event):
	async def ptg_serper_(event):
		cmd = 'botinfoserver'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
{z}
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await ptg_serper_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.CallbackQuery(data=b'servicee-ingpo'))
async def servicee_info(event):
	async def servicee_info_(event):
		cmd = 'botsis'.strip()
		await event.edit("Processing...")
		time.sleep(3)
		await event.edit("`Processing... 0%\n▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 20%\n████▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 40%\n███████▒▒▒▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 50%\n██████████▒▒▒▒▒▒▒▒▒▒ `")
		time.sleep(1)
		await event.edit("`Processing... 60%\n██████████████▒▒▒▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 80%\n█████████████████▒▒▒ `")
		time.sleep(2)
		await event.edit("`Processing... 100%\n████████████████████ `")
		time.sleep(1)
		await event.edit("`Wait.. Setting up Data Server`")
		time.sleep(1)
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""```{z}```
""",buttons=[[Button.inline("‹ Main Menu ›","server")]])
	sender = await event.get_sender()
	a = "true"
	if a == "true":
		await servicee_info_(event)
	else:
		await event.answer("Access Denied",alert=True)

@bot.on(events.NewMessage(pattern=r"(?:.server|/server)$"))
@bot.on(events.CallbackQuery(data=b'server'))
async def menu(event):
	inline = [
[Button.inline(" CEK SSH WS ","cuek-ssh")],
[Button.inline(" CEK VMESS ","cuek-vmess"),
Button.inline(" CEK VLESS ","cuek-vless")],
[Button.inline(" CEK TROJAN ","cuek-trojan"),
Button.inline(" CEK SHDWSK ","cuek-shadowsocks")],
[Button.inline(" SERVICE ","servicee-ingpo"),
Button.inline(" INFORMASI ","ptg-serper")],
[Button.url(" LAPORKAN BUG ","https://t.me/Mass_Alfin")]]
	sender = await event.get_sender()
	val = "true"
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' cat /etc/ssh/.ssh.db | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")
		vm = f' cat /etc/vmess/.vmess.db | grep "###" | wc -l'
		vms = subprocess.check_output(vm, shell=True).decode("ascii")
		vl = f' cat /etc/vless/.vless.db | grep "###" | wc -l'
		vls = subprocess.check_output(vl, shell=True).decode("ascii")
		tr = f' cat /etc/trojan/.trojan.db | grep "###" | wc -l'
		trj = subprocess.check_output(tr, shell=True).decode("ascii")
		shd = f' cat /etc/shadowsocks/.shadowsocks.db | grep "###" | wc -l'
		shdr = subprocess.check_output(shd, shell=True).decode("ascii")
		sdss = f" cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/=//g' | sed 's/PRETTY_NAME//g'"
		namaos = subprocess.check_output(sdss, shell=True).decode("ascii")
		ispvps = f" cat /etc/xray/isp"
		ispsaya = subprocess.check_output(ispvps, shell=True).decode("ascii")
		citsy = f" cat /etc/xray/city"
		city = subprocess.check_output(citsy, shell=True).decode("ascii")
		domx = f" cat /etc/xray/domain"
		dom = subprocess.check_output(domx, shell=True).decode("ascii")
		aktf = f" cekaktifbot"
		aktif = subprocess.check_output(aktf, shell=True).decode("ascii")
		msg = f"""
**◇━━━━━━━━━━━━━━━━━◇** 
 **🏠 INFO PANEL PATUNGAN 🏠**
**◇━━━━━━━━━━━━━━━━━◇**
**❖ OS     :** `{namaos.strip().replace('"','')}`
**❖ CITY :** `{city.strip()}`
**❖ DOMAIN :** `{dom.strip()}`
**❖ ISP :** `{ispsaya.strip()}`
**◇━━━━━━━━━━━━━━━━━◇**
**🎄 Jumlah Akun DIbuat 🎄** 
**🚀 SSH WS, OVPN:** `{ssh.strip()}` __account__
**🎭 XRAY VMESS  :** `{vms.strip()}` __account__
**🗼 XRAY VLESS  :** `{vls.strip()}` __account__
**🎯 XRAY TROJAN :** `{trj.strip()}` __account__
**🎲 XRAY SHDWSK :** `{shdr.strip()}` __account__
**◇━━━━━━━━━━━━━━━━━◇**
**⏰ Exp Server :** `{aktif.strip()}` __Hari Lagi__
**◇━━━━━━━━━━━━━━━━━◇**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


